TFS JMUN ready-to-upload photographs

CHAIRS
chairs/aippm-cochair.jpg
chairs/ccc-chair.jpg
chairs/hcc-chair.jpg
chairs/hcc-cochair.jpg
chairs/icj-cochair.jpg
chairs/unhrc-cochair.jpg
chairs/unsc-cochair.jpg

CONTACTS
contacts/faculty-1.jpg
contacts/faculty-2.jpg
contacts/press-1.jpg

All files have:
- the exact filenames expected by the website
- been converted to real JPEG files
- been cropped and resized consistently for the portrait boxes

After extracting this ZIP, upload the contents of the chairs folder into the
repository's chairs folder, and the contents of contacts into the repository's
contacts folder.
